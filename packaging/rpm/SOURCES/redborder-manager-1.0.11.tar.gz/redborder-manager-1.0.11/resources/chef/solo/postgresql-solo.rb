cookbook_path '/var/chef/cookbooks'
data_bag_path '/var/chef/data/data_bag/'
log_level :info
log_location STDOUT

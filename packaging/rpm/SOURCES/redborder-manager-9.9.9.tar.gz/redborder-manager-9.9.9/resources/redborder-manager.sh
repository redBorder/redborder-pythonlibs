export PATH=$PATH:/opt/opscode/embedded/bin
export LOGSTASH_PIPELINES_PATH="/etc/logstash/pipelines"